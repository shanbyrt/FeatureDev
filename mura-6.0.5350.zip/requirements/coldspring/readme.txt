Simply extract into your web root and run the quickstart guide at:

http://localhost/coldspring/examples/quickstart